# OOPPHPPDO
This is My Contribution for Open Library Concept.<br>
First Published 21 December 2015, <br>
Tinju Cepat OOP dengan PHP version 1.0<br>
Code Example : PHP<br>
<br><br>
Ebook Tinju Cepat OOP dengan PHP + Full Source Code<br>
Ebook ini membahas bagaimana melakukan pemograman berorientasi object menggunakan bahasa PHP.<br>
<br><br>
Content Table<br>
Chapter 1 : Apa itu Object Oriented Programming? <br>
Chapter 2 : Apa itu Class? Method dan Variable?<br>
Chapter 3 : Membuat Sebuah Object Menggunakan Class<br>
Chapter 4 : Memanggil Method dalam sebuah Object<br>
Chapter 5 : Apa itu Constructor Function?<br>
Chapter 6 : Apa itu Inheritance?<br>
Chapter 7 : Apa itu Function Overriding?<br>
Chapter 8 : Apa itu Access Modifier?<br>
Chapter 9 : Apa itu PDO (PHP Data Object)?<br>
Chapter 10 : Method Query()<br>
Chapter 11 : Method Exec()<br>
Chapter 12 : Try/Catch Statement<br>
Chapter 13 : Memahami Array<br>
Chapter 14 : Method Fetch()<br>
Chapter 15 : Prepared Statement<br>
Chapter 16 : Method bindParam()<br>
Chapter 17 : Fetch Style<br>
Chapter 18 : Finishing Touch<br>
Special Chapter : Quadruple Attack AJAX, PHP dan MySQL<br>

